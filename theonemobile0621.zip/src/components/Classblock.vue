<template>
    <div id="classblock">
        <div class="tubiao">
          <router-link class="biao1" tag="a" to="/Newhouse">
            <img src="../assets/images/icon1.png" alt="">
            <p>新房</p>
          </router-link>
          <router-link  class="biao2" tag="a" to="/Counter">
            <img src="../assets/images/icon2.png" alt="">
            <p>房贷</p>
          </router-link>
          <router-link class="biao3" tag="a" to="/Newlist">
            <img src="../assets/images/icon3.png" alt="">
            <p>楼讯</p>
          </router-link>
          <router-link  class="biao4" tag="a" to="/Middlemanall">
            <img src="../assets/images/icon4.png" alt="">
            <p>咨询</p>
          </router-link>
        </div>
    </div>
</template>

<script>
export default {
  name: 'classblock'
}
</script>

<style scoped>

</style>
