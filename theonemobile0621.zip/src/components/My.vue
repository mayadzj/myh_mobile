<template>
    <div id="my">
      <!-- 头部 -->
      <header class="my-header clear">
        <router-link tag="div" to="/Information" class="head-pic">
          <img :src="houseobj.headUrl" alt="">
        </router-link>
        <router-link tag="div" to="/Information" class="head-name">
          <p>{{houseobj.name}}</p>
        </router-link>
        <router-link tag="div" to="/Set" class="head-set">
          <img src="../assets/images/my/sz.png" alt="">
        </router-link>
        <div class="head-huodong">
          我的活动
        </div>
      </header>
      <!-- 内容 -->
      <nav class="my-content">
        <div class="n-wap">
          <div class="n-cls">
            <router-link tag="div" to="/Information">
              <img src="../assets/images/my/wo.png" alt="">
              <p>个人信息</p>
            </router-link>
            <router-link tag="div" to="/Record">
              <img src="../assets/images/my/kan.png" alt="">
              <p>浏览纪录</p>
            </router-link>
            <router-link tag="div" to="/Administrator">
              <img src="../assets/images/my/guanli.png" alt="">
              <p>房源管理</p>
            </router-link>
            <div>
              <img src="../assets/images/my/pinglun.png" alt="">
              <p>我的评论</p>
            </div>
          </div>
          <div class="n-cls">
            <router-link tag="div" to="/Mymiddleman">
              <img src="../assets/images/my/jingji.png" alt="">
              <p>我的经纪人</p>
            </router-link>
            <router-link tag="div" to="/Counter">
              <img src="../assets/images/my/jisuan.png" alt="">
              <p>房贷计算器</p>
            </router-link>
            <router-link tag="div" to="/Feedback">
              <img src="../assets/images/my/fankui.png" alt="">
              <p>用户反馈</p>
            </router-link>
            <router-link tag="div" to="/Apply">
              <img src="../assets/images/my/baoming.png" alt="">
              <p>我的报名</p>
            </router-link>
          </div>
        </div>
        <div class="n-pic">
          <img src="../assets/images/my/guanggao.png" alt="">
        </div>
        <div class="n-zi clear">
          <p onclick="window.location.href = 'tel://4001133233'">客服咨询<img src="../assets/images/my/you.png" alt=""></p>
          <p>关注我们<img src="../assets/images/my/you.png" alt=""></p>
        </div>
        <div class="n-fang clear">
          <div class="fang-tit clear">
            推荐房源
            <p>更多</p>
          </div>
          <div class="fang-right clear">
            <div class="f-tao">
              <div class="fang-xin">
                <div class="f-pic">
                  <img src="../assets/images/my/fangyuan.png" alt="">
                  <div class="jiage">
                    320<span>万</span>
                  </div>
                </div>
                <div class="f-mall-tit clear">
                  <p>御道庄园</p>
                  <p>承德市围场满族蒙古族自治区</p>
                </div>
                <div class="f-shi">
                  2室1厅1卫100／㎡
                </div>
              </div>
              <div class="fang-xin">
                <div class="f-pic">
                  <img src="../assets/images/my/fangyuan.png" alt="">
                  <div class="jiage">
                    320<span>万</span>
                  </div>
                </div>
                <div class="f-mall-tit clear">
                  <p>御道庄园</p>
                  <p>承德市围场满族蒙古族自治区</p>
                </div>
                <div class="f-shi">
                  2室1厅1卫100／㎡
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="bian"></div>
        <div class="kongbai"></div>
      </nav>
    </div>
</template>

<script>
import {getCookie} from '../util/cookie'
export default {
  name: 'my',
  data () {
    return {
      houseobj: {}
    }
  },
  mounted () {
    this.myhouse ()
  },
  methods: {
    myhouse () {
      var infos = {
        id: getCookie('userId')
      }
      this.$http.post(myHost + 'myh_web/selectUser',infos).then((response) => {
        var data = response.data
        data = data.resultBean
        data = data.object
        this.houseobj = data
        // console.log(data)
      })
    }
  }
};
</script>

<style scoped>
  .my-header .head-pic{
    position: relative;
  }
  .my-header .head-pic img{
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%,-50%);
  }
</style>
