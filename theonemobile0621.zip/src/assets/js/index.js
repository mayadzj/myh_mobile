var swiper = new Swiper('.swiper-container', {
    slidesPerView: 'auto',
});