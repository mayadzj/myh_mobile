// window.myHost = '/api/'
window.myHost = 'http://www.manyihefc.com:8080/'
