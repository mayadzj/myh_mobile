export default {
  tabtop(state){
    return state.tabtop
  },
  youname(state){
    return state.youname
  },
  topall(state){
    return state.topall
  },
  footer(state){
    return state.footer
  },
  sessionId (state) {
    return state.sessionId
  },
  phone (state) {
    return state.phone
  },
  userId(state) {
    return state.userId
  },
  isLog (state) {
    return state.isLog
  }
}
