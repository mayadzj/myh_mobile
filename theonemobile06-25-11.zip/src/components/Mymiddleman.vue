<template>
    <div id="mymiddleman">
      <div class="xinxi-kong"></div>
      <!-- 内容 -->
      <nav class="jingji-content clear">
        <!-- 切换 -->
        <div class="con-head">
          <div><span>服务我的经纪人</span></div>
          <div><span>我收藏的经纪人</span></div>
        </div>
        <!-- 浏览结果 -->
        <div class="con-nav">
          <!-- 单个 -->
          <div class="list">
            <div class="list-middle clear">
              <div class="list-pic">
                <div class="list-pic-wap">
                  <img src="../assets/images/head.jpg" alt="">
                </div>
              </div>
              <div class="list-tit">
                <p>刘某某</p>
                <p>手机号 : <span>17610276869</span></p>
                <p>承德御道县 : <span>御道庄园 (小区)</span></p>
                <div class="spa">
                  <span>客户好评</span>
                  <span>销售精英</span>
                  <span>销售顾问</span>
                </div>
                <img src="../assets/images/jin.png" alt="">
              </div>
              <div class="list-tel">
                <img src="../assets/images/tel.png" alt="">
              </div>
            </div>
          </div>
          <!-- 单个 -->
          <div class="list">
            <div class="list-middle clear">
              <div class="list-pic">
                <div class="list-pic-wap">
                  <img src="../assets/images/head.jpg" alt="">
                </div>
              </div>
              <div class="list-tit">
                <p>刘某某</p>
                <p>手机号 : <span>17610276869</span></p>
                <p>承德御道县 : <span>御道庄园 (小区)</span></p>
                <div class="spa">
                  <span>客户好评</span>
                  <span>销售精英</span>
                  <span>销售顾问</span>
                </div>
                <img src="../assets/images/jin.png" alt="">
              </div>
              <div class="list-tel">
                <img src="../assets/images/tel.png" alt="">
              </div>
            </div>
          </div>
          <!-- 单个 -->
          <div class="list">
            <div class="list-middle clear">
              <div class="list-pic">
                <div class="list-pic-wap">
                  <img src="../assets/images/head.jpg" alt="">
                </div>
              </div>
              <div class="list-tit">
                <p>刘某某</p>
                <p>手机号 : <span>17610276869</span></p>
                <p>承德御道县 : <span>御道庄园 (小区)</span></p>
                <div class="spa">
                  <span>客户好评</span>
                  <span>销售精英</span>
                  <span>销售顾问</span>
                </div>
                <img src="../assets/images/jin.png" alt="">
              </div>
              <div class="list-tel">
                <img src="../assets/images/tel.png" alt="">
              </div>
            </div>
          </div>
          <!-- 单个 -->
          <div class="list">
            <div class="list-middle clear">
              <div class="list-pic">
                <div class="list-pic-wap">
                  <img src="../assets/images/head.jpg" alt="">
                </div>
              </div>
              <div class="list-tit">
                <p>刘某某</p>
                <p>手机号 : <span>17610276869</span></p>
                <p>承德御道县 : <span>御道庄园 (小区)</span></p>
                <div class="spa">
                  <span>客户好评</span>
                  <span>销售精英</span>
                  <span>销售顾问</span>
                </div>
                <img src="../assets/images/jin.png" alt="">
              </div>
              <div class="list-tel">
                <img src="../assets/images/tel.png" alt="">
              </div>
            </div>
          </div>
          <!-- 单个 -->
          <div class="list">
            <div class="list-middle clear">
              <div class="list-pic">
                <div class="list-pic-wap">
                  <img src="../assets/images/head.jpg" alt="">
                </div>
              </div>
              <div class="list-tit">
                <p>刘某某</p>
                <p>手机号 : <span>17610276869</span></p>
                <p>承德御道县 : <span>御道庄园 (小区)</span></p>
                <div class="spa">
                  <span>客户好评</span>
                  <span>销售精英</span>
                  <span>销售顾问</span>
                </div>
                <img src="../assets/images/jin.png" alt="">
              </div>
              <div class="list-tel">
                <img src="../assets/images/tel.png" alt="">
              </div>
            </div>
          </div>
        </div>
        <div class="xinxi-kong"></div>
      </nav>
    </div>
</template>

<script>
export default {
  name: 'mymiddleman'
  // data () {
  //   houselist: {}
  // },
  // mounted () {
  //   this.myhouse()
  // },
  // methods: {
  //   myhouse  () {
  //     var infos = {
  //       type: 1
  //     }
  //     this.$http.post(myHost + 'myh_web/viewHouseInfo',infos).then((response) => {
  //       var data = response.data
  //       data = data.resultBean
  //       data = data.object
  //       data = data.list
  //       this.houselist = data
  //     })
  //   }
  // }
}
</script>

<style scoped>
  .jingji-content{
    margin-top: 0;
  }
  .jingji-content .con-head{
    margin-top: 0;
  }
</style>
